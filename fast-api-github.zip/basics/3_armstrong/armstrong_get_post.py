from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()

class Armstrong(BaseModel):
    num : int

@app.post("/armstrong")
def armstrong(data : Armstrong):
    numstr = str(data.num) # string of the number
    power = len(numstr) # length of the numbe to set the power
    
    total = sum(int(digit)** power for digit in numstr)
    
    result = data.num == total
    
    return {"number":data.num,"is armstrong?":result}