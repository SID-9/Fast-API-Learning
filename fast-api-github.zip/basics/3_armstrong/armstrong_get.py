from fastapi import FastAPI

app = FastAPI()

@app.get("/armstrong")
def armstrong(a: int):
    astr = str(a)
    power = len(astr)
    
    total = sum(int(digit)** power for digit in astr)
    
    result = a == total
    
    return {"number":a,"is armstrong":result}
