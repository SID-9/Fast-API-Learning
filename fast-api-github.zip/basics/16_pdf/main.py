from fastapi import FastAPI,UploadFile,status,File
import fitz
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware 

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class Response(BaseModel):
    filename: str
    contents:str
    
@app.post("/pdf-file",response_model=Response,status_code=status.HTTP_200_OK)
async def pdf_file(file:UploadFile=File(...)):
    content = await file.read()
    
    # open the pdf in bytes
    doc = fitz.open(stream=content,filetype="pdf")
    all_text = ""
    
    for page in doc:
        all_text += page.get_text()
        
    
    return Response(
        filename=file.filename,
        contents=all_text[:3000]# only the first 3000 characters
    )