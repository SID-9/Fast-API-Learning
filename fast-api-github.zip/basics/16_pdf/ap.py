import streamlit as st 
import requests 

backend_url = "http://localhost:8000"

st.title("PDF file handling")

uploaded_file = st.file_uploader("upload a pdf file : ",type=["pdf"])

if st.button("submit pdf"):
    files = {'file':(uploaded_file.name,uploaded_file,"application/pdf")}
    
    response = requests.post(f"{backend_url}/pdf-file",files=files)
    
    if response.status_code == 200:
        result = response.json()
        
        st.success(f"file uploaded is : {result['filename']}")
        st.write("here are the first 3000 characters from the file....")
        st.success(result['contents'])
    
    else:
        st.error("problem with file handling")