from fastapi import FastAPI
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=["*"],
    allow_headers=["*"],
    allow_methods=["*"],
)

class Factorial(BaseModel):
    num:int 

@app.post("/factorial")
def factorial(data : Factorial):
    fact = 1
    for i in range(1,data.num+1):
        fact *= i
    
    return {"number":data.num,"factorial":fact}

