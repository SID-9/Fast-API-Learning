from fastapi import FastAPI
from pydantic import BaseModel
app = FastAPI()

class Factorial(BaseModel):
    num : int
    
@app.post("/factorial")
def factorial(data : Factorial ):
    if data.num < 0:
        return {"error":"no factorial for negative numbers"}
    
    n = data.num
    fact = 1
    for i in range(1,n+1):
        fact *= i
    
    return {"number":n,"factorial":fact}