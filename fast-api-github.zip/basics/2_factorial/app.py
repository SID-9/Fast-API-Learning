import streamlit as st 
import requests

st.title("Factorial of a number....")
backend_url = "http://localhost:8000"
num = st.number_input("Enter your fav number: ",min_value=0,step=1)

if st.button("Calculate."):
    parameter = {
        'num':int(num)
        }
    
    response = requests.post(f"{backend_url}/factorial/",json=parameter)
    
    if response.status_code == 200:
        result = response.json()
        st.success(f"number:{result['number']}, factorial : {result['factorial']}")
    else:
        st.error("Problem connecting with the fastapi backend")