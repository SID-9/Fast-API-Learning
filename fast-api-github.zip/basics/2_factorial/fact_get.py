from fastapi import FastAPI

app = FastAPI()

@app.get("/factorial")
def factorial(a : int):
    if a < 0:
        return {"error" : "No factorial for negative numbers"}
    
    fact = 1
    for i in range(1,a+1):
        fact *= i
    
    return {"number":a,"factorial": fact}