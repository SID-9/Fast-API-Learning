import streamlit as st 
import requests 

backend_url = "http://localhost:8000"

name = st.text_input("Username : ")
email = st.text_input("Email : ")
pw = st.text_input("Password : ",type="password")

if st.button("Create account.."):
    payload ={
        'name':name,
        'email':email,
        'pw':pw
    }
    
    response = requests.post(f"{backend_url}/user-details",json=payload)
    
    if response.status_code == 201:
        result = response.json()
        
        st.success(result['msg'])
    else:
        st.error("problem connecting with the fastapi backend")