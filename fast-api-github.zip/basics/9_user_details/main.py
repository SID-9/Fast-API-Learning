from fastapi import FastAPI, status
from pydantic import BaseModel,EmailStr
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class UserDetails(BaseModel):
    name:str
    email:EmailStr
    pw:str
    
# RESPONSE MODEL
class Message(BaseModel):
    msg:str


# using status code = 201 means created
@app.post("/user-details",response_model=Message,status_code=status.HTTP_201_CREATED)
def user_details(data:UserDetails):
    return {"msg":f"Welcome {data.name} your account has been created."}