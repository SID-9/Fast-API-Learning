from fastapi import FastAPI,HTTPException
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
import faiss
import pandas as pd
import openai
from sentence_transformers import SentenceTransformer
import pickle


app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# load faiss index and dataset
index = faiss.read_index("marketing_faiss.index")
ds = pd.read_pickle("marketing_texts.pkl")
model = SentenceTransformer("all-MiniLM-L6-v2")

class AskGpt(BaseModel):
    prompt:str
    brand_name:str
    text_type:str
    
def search_marketing_text(query,text_type,top_k=3):
    query_embedding = model.encode([f"{text_type}:{query}"],normalize_embeddings=True)
    _,indices = index.search(query_embedding,top_k)
    results = ds.iloc[indices[0]]
    return results["text"].tolist()

def generate_gpt_marketing_text(prompt,brand_name,text_type):
    samples = search_marketing_text(prompt,text_type)
    full_prompt = f"""
    You are a marketing expert. Generate a {text_type} for a product based on the following details:

    Brand Name: {brand_name}
    User Request: {prompt}
    Sample Marketing {text_type}s for reference:
    1. {samples[0]}
    2. {samples[1]}
    3. {samples[2]}

    Now generate a fresh, engaging, and creative {text_type} tailored for {brand_name}.
    """
    
    response = openai.ChatCompletion.create(
        model = 'gpt-3.5-turbo',
        messages=[{"role":"user","content":full_prompt}],
        temperature = 0.8,
        max_tokens=300,
    )
    
    return response.choices[0].message.content.strip()


@app.post("/generate")
def generate_text(data: AskGpt):
    try:
        result = generate_gpt_marketing_text(data.prompt,data.brand_name,data.text_type)
        return {"result":result}
    except Exception as e:
        raise HTTPException(status_code=500,detail=str(e))
    

    