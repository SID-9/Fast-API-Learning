# app.py

import streamlit as st
import requests

st.title("🧠 AI Marketing Assistant")
st.subheader("Generate AI-powered marketing scripts and captions")

# Form
with st.form("marketing_form"):
    prompt = st.text_area("Enter your marketing prompt:")
    brand_name = st.text_input("Enter your brand name:")
    text_type = st.radio("Choose the type of marketing text:", ["script", "caption"])
    submitted = st.form_submit_button("Generate")

if submitted:
    if prompt and brand_name:
        with st.spinner("Generating marketing content..."):
            response = requests.post(
                "http://localhost:8000/generate",
                json={"prompt": prompt, "brand_name": brand_name, "text_type": text_type},
            )
            if response.status_code == 200:
                st.success("Generated Text:")
                st.write(response.json()["result"])
            else:
                st.error("Error: " + response.text)
    else:
        st.warning("Please fill in all fields.")
