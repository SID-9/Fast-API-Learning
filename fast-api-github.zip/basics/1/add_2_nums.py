from fastapi import FastAPI

app = FastAPI()

@app.get("/sum")
def add(a : int , b : int):
    res = a+b
    return {"result is : ",res}

@app.get("/subtract")
def subtract(a : int , b: int):
    if a > b:
        res = a-b
        return {"result a-b is : ", res}
    else:
        res = b - a 
        return {"result b-a is : ", res}
    

@app.get("/product")
def product(a : int , b : int):
    res = a*b
    return {"product is : ":res}

@app.post("/message")
def home():
    return {"hello everyone time for some maths"}