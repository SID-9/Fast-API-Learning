import streamlit as st 
import requests

backend_url = "http://localhost:8000"

st.title("3 math operations")

a = st.number_input("Enter 1st operand")
b = st.number_input("Enter 2nd operand")

if st.button("operate..."):
    parameters = {
        "a":a,
        "b":b
    }
    
    response = requests.post(f"{backend_url}/maths/", json=parameters)
    
    if response.status_code == 200:
        result = response.json()
        
        st.success("the results are...")
        #st.success("addition , subtraction , multiplication")
        st.success(f"addition : {result['addition']},subtraction : {result['difference']},multiplication : {result['product']}")
    else:
        st.error("Problem connecting with fastapi backend..")
