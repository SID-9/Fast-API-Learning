from fastapi import FastAPI
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

# help to connect frontend and backend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_headers=["*"],
    allow_methods=["*"],
)

class Maths(BaseModel):
    a : int
    b : int

@app.post("/maths")
def maths(data : Maths):
    
    # addition operation
    addition = data.a + data.b
    
    # subtraction operation
    if data.a > data.b:
        difference = data.a - data.b
    else:
        difference = data.b - data.a
    
    #multiplication
    product = data.a*data.b
    
    return {"addition":addition,"difference":difference,"product":product}