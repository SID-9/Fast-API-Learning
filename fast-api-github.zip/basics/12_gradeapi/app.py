import streamlit as st 
import requests

backend_url="http://localhost:8000"

st.title("Grades and Marks")

with st.form("Marks form"):
    name= st.text_input("Whats your name : ")
    marks = st.number_input("Enter your marks : ",min_value=0,max_value=100,step=1)
    submission = st.form_submit_button("Get grades")

if submission:
    payload = {
        'student':name,
        'marks':marks
    }
    
    try:
        response = requests.post(f"{backend_url}/grade-api",data=payload)
        
        if response.status_code == 200:
            result = response.json()
            
            st.success(f"{result['student']} with {result['marks']} marks has grade {result['grade']}")
        else:
            st.error("problems with computation")
        
        
    except Exception as e:
        st.error("error connecting with fastapi backend")
        st.exception(e)


