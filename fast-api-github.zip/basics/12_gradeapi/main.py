from fastapi import FastAPI, status,Form
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def grade_compute(marks):
    if marks>=90:
        return 'A'
    elif marks >=75 and marks < 80:
        return 'B'
    elif marks >=60 and marks < 75:
        return'C'
    elif marks >=45 and marks < 60:
        return 'D'
    elif marks >=30 and marks < 45:
        return 'E'
    else:
        return 'F'

# response model
class GradeApi(BaseModel):
    student:str
    marks:int
    grade:str
    
    
@app.post("/grade-api",response_model=GradeApi,status_code=status.HTTP_200_OK)
def grade_api(student: str=Form(...),marks: float=Form(...)):
    grade = grade_compute(marks)
    
    #return {"student":{student},"marks":{marks},"grade":{grade}}
    
    return GradeApi(student=student,marks=marks,grade=grade)