from fastapi import FastAPI,status,Form
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Response Model
class Bmi(BaseModel):
    bmi:float 
    category:str


def bmi_category(bmi):
    if bmi < 18.5:
        return 'underweight'
    elif bmi > 18.5 and bmi < 25:
        return 'normal'
    elif bmi > 25 and bmi < 30:
        return 'overweight'
    else:
        return 'obese'

@app.post("/bmi-calculator",response_model=Bmi, status_code=status.HTTP_200_OK)
def bmi_calculator(weight : float=Form(...), height : float=Form(...)):
    height_m = height/100 # convert height to meters (m)
    bmi = weight/(height_m**2)
    bmi = round(bmi,2)
    
    category = bmi_category(bmi)
    
    return {"bmi":bmi,"category":category}