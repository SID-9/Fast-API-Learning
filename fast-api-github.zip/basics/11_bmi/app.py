import streamlit as st 
import requests

backend_url = "http://localhost:8000"

st.title("BMI Calculator")

with st.form("BMI form"):
    height = st.number_input("Enter your height : ",min_value=1.0,step=0.1)
    weight = st.number_input("Enter your weight : ",min_value=1.0,step=0.1)
    
    submit = st.form_submit_button("Submit measurements")


if submit:
    payload = {
        'weight':weight,
        'height':height,
        
    }
    
    try:
        response = requests.post(f"{backend_url}/bmi-calculator",data=payload)
        
        if response.status_code == 200:
            result = response.json()
            
            st.success(f"Your BMI is {result['bmi']}-{result['category']}") 
            #st.json(response.json())
        else:
            st.error("Something went wrong in calculation")
            st.json(response.json())
    except Exception as e:
        st.error("couldnt connect to fastapi backend")
        st.exception(e)
    
    