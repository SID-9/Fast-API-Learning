from fastapi import FastAPI , status
from pydantic import BaseModel, EmailStr,Field
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class StudentInfo(BaseModel):
    name:str= Field(min_length=2,max_length=50)
    age:int = Field(gt=10,lt=100)
    email:EmailStr
    department:str
    
# response model
class ResponseMessage(BaseModel):
    msg:str
    
@app.post("/reg-student",response_model=ResponseMessage,status_code=status.HTTP_201_CREATED)

def reg_student(data:StudentInfo):    
    return {"msg":f"student {data.name} from {data.department} registered successfully"}
