import streamlit as st 
import requests

backend_url = "http://localhost:8000"

with st.form("Student Form"):
    name=st.text_input("Enter your name : ")
    age = st.number_input("Enter your age : ",min_value=1, max_value=100)
    email= st.text_input("Enter your email : ")
    department = st.selectbox("select your department",["CSE","ECE","ECM","CIVIL","MECH"])

    submit = st.form_submit_button("Register")
    
if submit:
    payload = {
        'name':name,
        'age':age,
        'email':email,
        'department':department
    }
    
    try:
        response = requests.post(f"{backend_url}/reg-student",json=payload)
        
        if response.status_code == 201:
            result = response.json()
            
            st.success(result['msg'])
        else:
            st.error(f"Registration failed. Status code: {response.status_code}")
            st.json(response.json())  # shows validation errors if any
    
    except Exception as e:
        st.error("Problem connecting with fastapi backend")
        st.exception(e)
        
