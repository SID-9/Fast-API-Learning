import streamlit as st 
import requests

backend_url = "http://localhost:8000"

st.title("Text File Reader..")

uploaded_file = st.file_uploader("Choose a txt file ", type="txt")

if uploaded_file is not None:
    files = {"file": uploaded_file.getvalue()}
    
    response = requests.post(f"{backend_url}/txt-file",
                             files = {"file": (uploaded_file.name, uploaded_file, "text/plain")}
                             )
    
    if response.status_code == 200:
        result = response.json()
        
        st.success(f"Filename : {result['filename']}")
        st.text_area("Content :", result['content'],height=300)
    else:
        st.error("problem reading file")
        