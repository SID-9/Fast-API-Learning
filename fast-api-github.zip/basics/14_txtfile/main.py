from fastapi import FastAPI,UploadFile,File,status
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.post("/txt-file",status_code=status.HTTP_200_OK)
async def txt_file(file: UploadFile=File(...)):
    content = await file.read()
    
    return {'filename':file.filename,'content':content.decode("utf-8")}