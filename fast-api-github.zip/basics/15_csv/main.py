from fastapi import FastAPI,status,UploadFile,File
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
import pandas as pd


app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.post("/csv-file")
async def csv_file(file : UploadFile=File(...)):
    df = pd.read_csv(file.file)
    preview = df.head().to_dict(orient="records")
    
    return {
        "filename":file.filename,
        "columns": list(df.columns),
        "preview": preview
        
    }