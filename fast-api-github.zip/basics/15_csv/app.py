import streamlit as st 
import requests
import pandas as pd

backend_url="http://localhost:8000"

uploaded_file = st.file_uploader("Upload a  csv file : ",type="csv")

if st.button("submit"):
    files = {
        "file":(uploaded_file.name,uploaded_file,"text/csv")
    }
    
    response = requests.post(f"{backend_url}/csv-file",files=files)
    
    if response.status_code==200:
        result = response.json()
        
        st.success(f"file uploaded is : {result['filename']}")
        st.write("**columns : **",result['columns'])
        st.write("**preview**")
        st.dataframe(pd.DataFrame(result['preview']))
    else:
        st.error("problem while handling file")

