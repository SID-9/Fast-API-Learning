import streamlit as st 
import requests

st.title = "greet and reverse!!"

backend_url = "http://localhost:8000"

name = st.text_input("What should I call you ?")

if st.button("Hit meee.."):
    parameter = {
        'stmt':str(name)
    }
    
    response = requests.post(f"{backend_url}/greet/",json=parameter)
    
    if response.status_code == 200:
        result = response.json()
        
        st.success(' '.join(result))
        
    else:
        st.error("problem connecting with fastapi backend")
    
    
# quote part
quote = st.text_input("quote here ....")
label = "how would this look if reversed ? wanna check ?? "
answer = st.radio(label=label,options=["**yes**","**no**"])
        
if answer == "**yes**":
    if st.button("reverseee"):
            
        parameter2 = {
        'stmt':str(quote)
        }
                
        response2 = requests.post(f"{backend_url}/reversed/",json=parameter2)
                
        if response2.status_code == 200:
            result2 = response2.json()
            st.success(' '.join(result2))
else:
    st.write("Soooo Booriiinnggg..")