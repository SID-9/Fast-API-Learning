from fastapi import FastAPI
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class GREET(BaseModel):
    stmt:str
    
class REVERSE(BaseModel):
    stmt:str


@app.post("/greet")
def greet(data:GREET):
    st1 = "Hiii "
    st2 = ", Hit me with your fav quote ? "
    return {f"{st1}{data.stmt}{st2}"}

@app.post("/reversed")
def reversed(data:REVERSE):
    return {f"{data.stmt[::-1]}"}

