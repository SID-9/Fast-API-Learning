import streamlit as st 
import requests 

backend_url ="http://localhost:8000"

st.title('TO-DO LIST')

name = st.text_input("Enter your name ? ")
task_input = st.text_area("Enter your tasks (one per line) : ")

if st.button("Get Tasks Summary.."):
    if name and task_input.strip():
        tasks = [task.strip() for task in task_input.split('\n') if task.strip()]

        payload={
            'name':name,
            'tasks':tasks
        }
        
        response = requests.post(f"{backend_url}/tasks",json=payload)
        
        if response.status_code == 200:
            result = response.json()
            
            st.success({result['message']})
            st.write(f"Total tasks : {result['total_tasks']}")
            st.write("Here's your to-do list....")
            for i,task in enumerate(result['task_list'],start=1):
                st.markdown(f"{i}. {task}")
            
        else:
            st.error("something went wrong in displaying!?")
    
    else:
        st.error("Please fill out all the fields.")