from fastapi import FastAPI,status
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
from typing import List

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class ToDoList(BaseModel):
    name:str
    tasks: List[str]
    
# response model
class TaskResponse(BaseModel):
    user:str
    total_tasks:int
    task_list: List[str]
    message:str
    
# Endpoint
@app.post('/tasks',response_model=TaskResponse,status_code=status.HTTP_200_OK)
def tasks(data:ToDoList):
    return TaskResponse(
        user= data.name,
        total_tasks= len(data.tasks),
        task_list=data.tasks,
        message=f"{data.name},you have {len(data.tasks)} to complete today!"
    )