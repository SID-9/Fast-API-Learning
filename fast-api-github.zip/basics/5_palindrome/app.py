import streamlit as st 
import requests

st.title("check if the number is a palidrome or not!")

backend_url = "http://localhost:8000"

num = st.number_input("Enter the number to be checked : ",min_value=0, step=1)

if st.button("check it..."):
    parameter = {"num":int(num)}
    response = requests.post(f"{backend_url}/palindrome/",json=parameter)
    
    if response.status_code == 200:
        result = response.json()
        
        if result["is_palindrome"]:
            st.success(f"{result['number']} is a palindrome!!")
        else:
            st.error(f"{result['number']} is not a palindrome")
    else:
        st.error("problem connecting with fastapi backend...")