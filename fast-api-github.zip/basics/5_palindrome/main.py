from fastapi import FastAPI
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins = ["*"],
    allow_credentials=True,
    allow_headers = ["*"],
    allow_methods = ["*"],
)

class Palindrome(BaseModel):
    num : int
    
@app.post("/palindrome")
def palindrome(data : Palindrome):
    numstr = str(data.num)
    
    result = numstr == numstr[::-1]
    
    return {"number":data.num,"is_palindrome":result}