from fastapi import FastAPI
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins = ["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class Vowels(BaseModel):
    stmt:str

@app.post("/vowels")
def vowels(data:Vowels):
    cnt = 0
    for char in str(data.stmt):
        if char in ['a','e','i','o','u','A','E','I','O','U']:
            cnt += 1
    
    return {"result":cnt}