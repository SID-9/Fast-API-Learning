import streamlit as st 
import requests

backend_url = "http://localhost:8000"

st.title("Count the vowels")

stmt = st.text_input("Your opinion on multiple genders ? ")

if st.button("count it"):
    parameters = {
        'stmt':str(stmt)
    }
    
    response = requests.post(f"{backend_url}/vowels/",json=parameters)
    
    if response.status_code == 200:
        results = response.json()['result']
        
        st.success(f"The number of vowels is : {results}")
    
    else:
        st.error("problem connecting with the fastapi backend")