# age validation app

from fastapi import FastAPI,status
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins={"*"},
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class UserInfo(BaseModel):
    name:str
    age:int

# response model
class Message(BaseModel):
    message:str


@app.post("/check-age",response_model=Message,status_code= status.HTTP_200_OK)
def check_age(data:UserInfo):
    if data.age > 18:
        msg = f"Hii {data.name} you are an adult"
    else:
        msg = f"Hii {data.name} you are a minor"
    
    return {"message":msg}