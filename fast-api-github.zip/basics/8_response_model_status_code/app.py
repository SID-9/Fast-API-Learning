import streamlit as st 
import requests 

backend_url = "http://localhost:8000"

st.title("AGE CHEKCER APP")

name =st.text_input("Enter your name ? ")
age = st.number_input("What is your age ? ",min_value=1,step=1)

if st.button("check"):
    payload = {
        'name':str(name),
        'age':int(age)
    }
    
    response = requests.post(f"{backend_url}/check-age",json=payload)
    
    if response.status_code == 200:
        result = response.json()
        
        st.success(f"{result['message']}")
    else:
        st.error("problem connecting with fastapi backend")