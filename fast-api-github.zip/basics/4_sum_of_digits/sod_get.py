from fastapi import FastAPI

app = FastAPI()

@app.get("/sod")
def sod(n : int):
    total = sum(int(digit) for digit in str(n))
    return {"number is ":n,"sum of digits is":total}