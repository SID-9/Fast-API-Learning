from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()

class SOD(BaseModel):
    num : int
    
@app.post("/sod")
def sod(data : SOD):
    total = sum(int(digit) for digit in str(data.num))
    return {"number":data.num,"sum of digits is ":total}