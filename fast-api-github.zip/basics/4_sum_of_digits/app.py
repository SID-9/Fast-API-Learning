import streamlit as st 
import requests

backend_url = "http://localhost:8000"

st.title("Sum Of Digits")

num = st.number_input("Enter you fav number..")

if st.button("SUM"):
    parameter = {
        'num':int(num)
    }
    
    response = requests.post(f"{backend_url}/sod/",json=parameter)
    
    if response.status_code == 200:
        result = response.json()
        
        st.success(f"number: {result['number']}, sum of digits : {result['sum_of_digits']}")
    else:
        st.error("Problem connecting with fast api backend..")