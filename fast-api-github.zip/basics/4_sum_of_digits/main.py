from fastapi import FastAPI
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class SOD(BaseModel):
    num:int

@app.post("/sod")
def sod(data:SOD):
    total = sum(int(digit) for digit in str(data.num))
    return {"number":data.num,"sum_of_digits":total}